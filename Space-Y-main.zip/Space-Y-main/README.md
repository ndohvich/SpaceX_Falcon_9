# Space-Y
Data Science project. Using data science to discover the possibility of competing with  SpaceX.
